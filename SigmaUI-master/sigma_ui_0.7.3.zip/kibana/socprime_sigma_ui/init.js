let Main                = require('./server/routes/common/main');
let SigmaDoc            = require('./server/routes/sigma/get-doc');
let SigmaGetTranslation = require('./server/routes/sigma/get-translation');
let GetFile             = require('./server/routes/common/get-file');

/**
 * @param server
 * @param options
 */
export default function (server, options) {
    server.route({ method: 'GET',  path: '/app/socprime_sigma_ui/main',              handler: (req,reply) => Main(server, options).index(req,reply) });
    server.route({ method: 'GET',  path: '/app/socprime_sigma_ui/sigma-doc',         handler: (req,reply) => SigmaDoc(server, options).index(req,reply) });
    server.route({ method: 'GET',  path: '/app/socprime_sigma_ui/sigma-translation', handler: (req,reply) => SigmaGetTranslation(server, options).index(req,reply) });
    server.route({ method: 'GET',  path: '/app/socprime_sigma_ui/get-file',          handler: (req,reply) => GetFile(server, options).index(req,reply) });
};
