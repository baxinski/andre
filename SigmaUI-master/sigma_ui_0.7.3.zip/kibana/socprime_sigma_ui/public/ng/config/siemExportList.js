let data = {
    "es-qs": {
        "name": "Elasticsearch Query",
    },
    "kibana": {
        "name": "Kibana JSON",
    },
    "xpack-watcher": {
        "name": "X-Pack Watcher JSON",
    },
    "arcsight": {
        "name": "ArcSight Search Query",
    },
    "qualys": {
        "name": "Qualys IOC Search",
    },
    "qradar": {
        "name": "QRadar AQL",
    },
    "splunk": {
        "name": "Splunk Search Query",
    },
    "logpoint": {
        "name": "LogPoint Query",
    },
    "graylog": {
        "name": "Graylog Search",
    },
    "grep": {
        "name": "Regex Grep Search",
    },
    "wdatp": {
        "name": "Windows Defender",
    }
};

module.exports = data;
