import uiRoutes from 'ui/routes';

require('ui/autoload/all');
require('ui/chrome');

import * as d3 from 'd3';
window.d3 = d3;
import * as c3 from 'c3';
window.c3 = c3;

window.YAML = require('yamljs');

/*import * as gridstack from 'gridstack';
window.gridstack = gridstack;*/

// Include assets
import './assets/css/reset.css';
import './assets/plugins/bootstrap/bootstrap.min.css';
import './../node_modules/gridstack/dist/gridstack.css';

// DataTables
import './assets/plugins/datatables/dataTables.bootstrap4.min.css';
import './assets/plugins/datatables/buttons.bootstrap4.min.css';
// Responsive datatable
import './assets/plugins/datatables/responsive.bootstrap4.min.css';
import './assets/plugins/font-awesome/css/font-awesome.min.css';
import './assets/plugins/bootstrap-datepicker/bootstrap-datepicker.min.css';
import './../bower_components/angular-ui-tree/dist/angular-ui-tree.css';
import './assets/plugins/select2/select2.css';
import './assets/plugins/jsoneditor/jsoneditor.css';
import './assets/css/sidebar.css';
import './assets/plugins/c3/c3.css';
import './assets/css/menu-button.css';
import './assets/css/old-style.css';
import './assets/css/style.css';
import './assets/css/style-light.css';

import './assets/js/jquery-2.1.1';
import './assets/plugins/bootstrap/bootstrap.min';

// Required datatable js
import './assets/plugins/datatables/jquery.dataTables.min';
import './assets/plugins/datatables/dataTables.bootstrap4';
import './assets/dataTables.responsive';

// import './assets/plugins/jquery-ui/jquery-ui.min.js';
// import './assets/plugins/gridstack/lodash.min.js';
// import './assets/plugins/gridstack/knockout-min.js';
// import './assets/plugins/gridstack/jquery.ui.touch-punch.min.js';
// import './assets/plugins/gridstack/gridstack.js';
// import './assets/plugins/gridstack/gridstack.jQueryUI.js';

//import './assets/plugins/converters/jsontoyaml.js';
import './assets/plugins/select2/select2';
import './assets/plugins/bootstrap-datepicker/bootstrap-datepicker.min';
import './../bower_components/angular-ui-tree/dist/angular-ui-tree';

// import './assets/plugins/yaml.js-develop/dist/yaml';
import './assets/js/main';
//import './ng/helpers/init/editor';

import './assets/js/customCharts';

// require Serveces
require('./ng/services/common/modal');

// require Directives
require('./ng/directives/sp-top-nav/index');
require('./ng/directives/sp-yaml-editor/index');
require('./ng/directives/sp-visual-editor/index');
require('./ng/directives/sp-select-sigma/index');
require('./ng/directives/sp-convert-to-siem/index');
require('./ng/directives/sp-footer/index');

// require Constrollers
require('./ng/controllers/main');

uiRoutes.enable();
uiRoutes.when('/', {
    template: require('./ng/views/main.html'),
    reloadOnSearch: false
});
uiRoutes.otherwise({
    redirectTo: '/'
});
