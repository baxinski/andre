ES_host = ['localhost']
ES_http_auth = 'None'
ES_port = 9200
ES_scheme = "http"

SIGMA_DOC_INDEX_NAME = "uncoder_doc"
SIGMA_TRANSLATION_INDEX_NAME = "uncoder_translation"

