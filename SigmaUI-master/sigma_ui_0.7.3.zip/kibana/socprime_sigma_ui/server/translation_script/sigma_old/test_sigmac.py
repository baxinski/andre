﻿import sys
import os, shutil, stat
# import argparse
# import time
import subprocess

from logger import Logger
# from pm_db_connector import PM_DB_Connector


def exec_shell_command(command):
    p = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    p.wait()
    return (p.returncode, p.stdout.read().strip(), p.stderr.read().strip())



if __name__ == "__main__":

    currentdir = os.path.dirname(os.path.abspath(__file__))

    main_dir = os.path.normpath(currentdir) #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

    sigma_config_path = os.path.normpath(main_dir + '/tools/config/')
    converter_path = os.path.normpath(main_dir + '/tools/sigmac.py')


    logger = Logger('sigma_converter')
    logger.info('Script started ==============================')


    out_format = 'as'# название бекенда
    filepath = 'D:\\WORK\\GIT\\sigma\\sigma_git\\sigma\\rules\\apt\\apt_elise.yml'# путь к сигме



    try:
        exit_code = 0
        rezult = ''

        # маппинг бекенда и конфига
        if out_format == 'as':
            sigma_config = '-c ' + os.path.normpath(sigma_config_path + '/arcsight.yml')
        elif out_format == 'qualys':
            sigma_config = '-c ' + os.path.normpath(sigma_config_path + '/qualys.yml')
        else:
            sigma_config = ''


        command = "py {} {} -t {} {}".format(converter_path, sigma_config, out_format, filepath) #py
        #logger.info(command)
        (exit_code, rezult, error_text) = exec_shell_command(command)

        #logger.info('{}, {}'.format(str(exit_code), str(rezult)))
        print exit_code, rezult, error_text

        if exit_code == 0:
            # тут пишем результат в еластик
            pass
        else:
            logger.error('error')

    except Error as e:

        logger.error(str(e) + ' ' + error_text)
        print e.db_error_code,  str(e)

