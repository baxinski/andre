# -*- coding: utf-8 -*-
#!/usr/bin/env python

__author__ = 'Nikolay Trofimyuk'
__version__ = '0.1'


import subprocess
import os
import datetime
import json
import hashlib
#from mysql.connector import MySQLConnection, Error
import MySQLdb
from ConfigParser import ConfigParser

from logger import Logger


#import pprint #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

# TODO:

def exec_shell_command(command):
    p = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    p.wait()
    if p.returncode == 2:
        msg  = 'System returned an error while running the command: {0}'.format(p.stderr.read().strip())
        raise Exception(msg)
    return p.stdout.read().strip()


class PM_DB_Connector(object):

    def __init__(self):
        self.logger = Logger('pm_db_connector')
        #self.component_id = component_id
        self.conn = None
        self.db_config = self.read_db_config_old() #'/srv/scripts/ucl/config.ini'
        if not self.db_config:
            self.db_config = self.read_db_config()
        self.connect_to_mysql()


    def read_db_config(self):
        command = "cat /srv/scripts/config_web | openssl  smime -decrypt -binary -inform DEM -inkey /usr/libexec/systemtap/stap_io | grep {0} | awk -F '=' '{{print$2}}'"
        try:
            db = {
                'host':     exec_shell_command(command.format('MyHOST')),
                'database': exec_shell_command(command.format('MyDB')),
                'user':     exec_shell_command(command.format('MyUSER')),
                'password': exec_shell_command(command.format('MyPASS'))
                }
        except Exception as error:
            self.logger.error('Unable to get PM DB credentials. Error:'+ str(type(error))+ ': ' + str(error))
            raise Exception('Unable to connect to PM DB')
        else:
            return db


    def read_db_config_old(self, filename='config.ini', section='mysql'): #/srv/scripts/sigma/sigma_git_clone/
        # create parser and read ini configuration file
        if not os.path.exists(filename):
            return False

        fn = os.path.normpath(filename)
        parser = ConfigParser()
        parser.read(fn)

        # get section, default to mysql
        db = {}
        if parser.has_section(section):
            items = parser.items(section)
            for item in items:
                db[item[0]] = item[1]
        else:
            raise Exception('{0} not found in the {1} file'.format(section, filename))

        return db





    def connect_to_mysql(self):
        try:
            if (not self.conn):# or (not self.conn.is_connected()):
                self.logger.info('Connecting to MySQL database...')
                self.conn = self.conn = MySQLdb.connect(host=self.db_config['host'], user=self.db_config['user'], passwd=self.db_config['password'], db=self.db_config['database'])
                self.conn.autocommit = False
                self.logger.info('Connection established.')
        except Exception as e:
            self.logger.error(str(type(e))+ ': ' + str(e))
            raise

    def close_db_connection(self):
        if self.conn:# and self.conn.is_connected():
            self.conn.close()

# #######################################################################
    def get_file_name(self, case_id):
        self.connect_to_mysql()

        query = "SELECT `file_path` FROM sigma_export_status WHERE id={0} LIMIT 1;".format(case_id)
        cursor = self.conn.cursor()
        cursor.execute(query)
        filename = cursor.fetchone()
        if filename:
            filename = filename[0]
        else:
            filename = None
        cursor.close()
        return filename

    def update_document_status(self, status_code, ucl_id):
        self.connect_to_mysql()
        query = "UPDATE sigma_export_status SET `status`= {0} WHERE `id` = {1}".format(status_code, ucl_id)
        cursor = self.conn.cursor()
        cursor.execute(query)
        cursor.close()
        self.conn.commit()

    def update_document(self, values_list):
        self.connect_to_mysql()
        query = "UPDATE sigma_export_status SET `status`=%s, message=%s WHERE `id`=%s"
        cursor = self.conn.cursor()
        cursor.execute(query, values_list)
        cursor.close()
        self.conn.commit()

# git clone ##########################################


    def insert_sigma(self, data_dict):
        self.connect_to_mysql()

        query = """INSERT INTO sigma_document (permission_id,title, description, status, level, category, author, released, sigma_text, hash, git_filepath) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"""
        cursor = self.conn.cursor()
        cursor.execute(query, (
            data_dict['permission_id'], data_dict['title'], data_dict['description'],
            data_dict['status'],
            data_dict['level'], data_dict['category'], data_dict['author'], data_dict['released'],
            data_dict['sigma_text'],
            data_dict['hash'], data_dict['git_filepath']))
        inserted_id = cursor.lastrowid
        self.logger.info('Entry inserted in db - [title={}], [path={}]'.format(data_dict['title'], data_dict['git_filepath']))
        cursor.close()
        self.conn.commit()
        return inserted_id


    def update_sigma(self, data_dict):
        self.connect_to_mysql()

        query_select = """SELECT id FROM sigma_document where git_filepath = %s"""
        cursor = self.conn.cursor()
        cursor.execute(query_select, (data_dict['git_filepath'],))
        ids = cursor.fetchone()
        if ids == None:
            self.logger.info('Entry absent in db - [file_name = {}] [title = {}]'.format(data_dict['git_filepath'], data_dict['title']))
            #print("ids == None")
        else:
            #self.logger.info('[id = {}] [title = {}] - start write to db'.format(ids[0], data_dict['title']))
            query = """UPDATE sigma_document SET title = %s, description = %s, status = %s, level = %s, category = %s, author = %s, released = %s, sigma_text = %s, hash = %s, git_filepath = %s WHERE id = %s"""
            cursor = self.conn.cursor()
            cursor.execute(query, (
                data_dict['title'], data_dict['description'],
                data_dict['status'], data_dict['level'], data_dict['category'], data_dict['author'], data_dict['released'],
                data_dict['sigma_text'], data_dict['hash'], data_dict['git_filepath'], ids[0]))
            self.logger.info('Entry updated in db - [file_name = {}] [title = {}]'.format(data_dict['git_filepath'], ids[0], data_dict['title']))
            cursor.close()
            self.conn.commit()
            return ids[0]
        #print ids[0]


    def get_category_tree_dict(self):
        self.connect_to_mysql()

        query_select = """SELECT L1.id, CONCAT_WS('/','',L5.name, L4.name, L3.name, L2.name, L1.name) as path
        FROM sigma_category_tree L1
        LEFT JOIN sigma_category_tree L2 ON L1.parent_id = L2.id
        LEFT JOIN sigma_category_tree L3 ON L2.parent_id = L3.id
        LEFT JOIN sigma_category_tree L4 ON L3.parent_id = L4.id
        LEFT JOIN sigma_category_tree L5 ON L4.parent_id = L5.id"""
        cursor = self.conn.cursor()
        cursor.execute(query_select)
        rez_dict = {}
        for (cat_id, path) in cursor:
            rez_dict[path] = cat_id

        return rez_dict

    def insert_notifications(self, added_ids, updated_ids):
        self.connect_to_mysql()
        
        query = """INSERT INTO notification (code_id, sigma_id, created) VALUES (%s, %s, %s)"""        
        cursor = self.conn.cursor()
        now = datetime.datetime.now()
        
        for sigma_id in added_ids:
            cursor.execute(query, (9, sigma_id, now))
        
        for sigma_id in updated_ids:
            cursor.execute(query, (10, sigma_id, now))    
            
        cursor.close()
        self.conn.commit()                

# ###############################################################################
if __name__ == "__main__":
    try:
        dbc = PM_DB_Connector()

        print dbc.get_category_tree_dict()

        dbc.close_db_connection()
    except Exception as e:
        #dbc.logger.error(str(type(e))+ ': ' + str(e))
        print str(type(e))+ ': ' + str(e)
        raise


