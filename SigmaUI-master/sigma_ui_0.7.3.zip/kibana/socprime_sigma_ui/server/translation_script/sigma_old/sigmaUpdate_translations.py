﻿#!/usr/bin/python

import os
import re
import subprocess


from logger import Logger
#from pm_db_connector import PM_DB_Connector
from es_db_connector import ES_DB_Connector


all_backends = ["wdatp"] #["kibana", "xpack-watcher", "logpoint", "splunk", "grep", "arcsight", "qualys", "graylog", "qradar", "wdatp"]
currentdir = os.path.dirname(os.path.abspath(__file__))
path = '/srv/sigma_git/' # for prod
if not os.path.exists(path):
    path = os.path.normpath(currentdir + '/sigma_git/') # for local testing

sigma_config_path = os.path.normpath(currentdir + '/tools_new/config/')
converter_path = os.path.normpath(currentdir + '/tools_new/sigmac.py')

reptrn_git_filepath = re.compile(r'\/rules((?:\/[^\/]+?)+\.yml)')
#reptrn_git_filepath = re.compile(r'\\rules((?:\\[^\\]+?)+\.yml)')


def exec_shell_command(command):
    p = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    p.wait()
    return (p.returncode, p.stdout.read().strip(), p.stderr.read().strip())

def translate_sigma(filepath, out_format):
    exit_code = 0
    rezult = ''

    # маппинг бекенда и конфига
    if out_format == 'arcsight':
        sigma_config = '-c ' + os.path.normpath(sigma_config_path + '/arcsight.yml')
    elif out_format == 'qualys':
        sigma_config = '-c ' + os.path.normpath(sigma_config_path + '/qualys.yml')
    elif out_format == 'qradar':
        sigma_config = '-c ' + os.path.normpath(sigma_config_path + '/qradar.yml')
    else:
        sigma_config = ''

    command = "/usr/local/bin/python3.6 {} {} -t {} {}".format(converter_path, sigma_config, out_format, filepath) #/usr/local/bin/python3.6
    (exit_code, rezult, error_text) = exec_shell_command(command)

    if exit_code == 0:
        return rezult
    else:
        raise Exception(error_text)


def update_sigma_translations(filepath, sigma_doc_id):
    for backend_name in all_backends:
        try:
            text = translate_sigma(filepath, backend_name)
            if text:
                data = {
                    'sigma_doc_id': sigma_doc_id,
                    'backend': backend_name,
                    'text': text
                    }
                es_dbc.upsert_sigma_translations(data)
        except Exception as e:
            logger.error("Sigma translation error [{}, {}]: {}".format(sigma_doc_id, backend_name, str(e)))


def get_sigma_git_filepath(filepath):
    git_filepath = None
    match = reptrn_git_filepath.search(filepath)
    if match:
        git_filepath = match.group(1)
    
    return git_filepath

if __name__ == '__main__':
    logger = Logger("sigmaUpdate_translations")

    es_dbc = ES_DB_Connector()
    
    sigma_dict = es_dbc.sigma_doc_git_dict
    
    # get_all_sigma_doc_list
    # for sigma in get_all_sigma_doc_list
    # get_sigma_doc_by_id(self, sigma_doc_id)
    # get "sigma_text"
    # write to file
    # translate
    # update_sigma_translations
    
    sigma_path = os.path.join(currentdir, 'tmp_sigma.yml')
    sigma_doc_id_list = es_dbc.get_all_sigma_doc_list()

    for sigma_doc_id in sigma_doc_id_list:
        res = es_dbc.get_sigma_doc_by_id(sigma_doc_id)
        entry = res["sigma_text"]
        
        with open(sigma_path, 'w') as yml_file:
            yml_file.write(entry + '\n')
        update_sigma_translations(sigma_path, sigma_doc_id)
        os.unlink(sigma_path)



 