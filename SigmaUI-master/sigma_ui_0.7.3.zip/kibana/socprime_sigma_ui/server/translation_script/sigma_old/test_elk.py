﻿from datetime import datetime
from elasticsearch import Elasticsearch
import hashlib


es = Elasticsearch(
    #['10.10.14.21'],
    ['srv-elk-031.office.socprime.com'],
    http_auth=('kibana', 'kibana+1'),
    scheme="https",
    port=9200,
)

def insert_sigma_doc():
    doc = {
        #'id': 'M_test__R',
        'user_id': 3,
        'permission_id': 3,

        'title': 'Ruby on Rails framework exceptions Test',
        'status': 'experimental',
        'level': 'medium',
        'author': 'Thomas Patzke',
        'sigma_text':  """title: Ruby on Rails framework exceptions
description: Detects suspicious Ruby on Rails exceptions that could indicate exploitation attempts
author: Thomas Patzke
reference:
    - http://edgeguides.rubyonrails.org/security.html
    - http://guides.rubyonrails.org/action_controller_overview.html
    - https://stackoverflow.com/questions/25892194/does-rails-come-with-a-not-authorized-exception
    - https://github.com/rails/rails/blob/master/actionpack/lib/action_dispatch/middleware/exception_wrapper.rb
logsource:
    category: application
    product: ruby_on_rails
detection:
    keywords:
        - ActionController::InvalidAuthenticityToken
        - ActionController::InvalidCrossOriginRequest
        - ActionController::MethodNotAllowed
        - ActionController::BadRequest
        - ActionController::ParameterMissing
    condition: keywords
falsepositives:
    - Application bugs
    - Penetration testing
level: medium""",

        'hash': '222d3c707bc7239eb2c74cca5d3eed24eabbabf455982fd8c4d6a6f913dfd111',
        'git_filepath': '/application/appframework_ruby_on_rails_exceptions.yml',
        'category': 1,

        'released': datetime.now(), #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        'updated': datetime.now(), #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        'downloads': 1,
        'mitre_attack': None,
        'is_verified': False

    }

    res = es.index(index="sigma_doc", doc_type='sigma_doc', body=doc)
    print(res)

##res = es.get(index="sigma_test", doc_type='sigma_doc', id='riJ8vmIBTblFQ9HVEFHH')
##print(res['_source'])
#print es.delete (index="device_trend_h_2018.03.15", doc_type='device_trend_h')
#print es.indices.get_alias("device_src*")

#insert_sigma_doc()



def insert_translations():

    doc_list = []

    text = """(exe:("\/tmp\/*" "\/var\/www\/*" "\/usr\/local\/apache2\/*" "\/usr\/local\/httpd\/*" "\/var\/apache\/*" "\/srv\/www\/*" "\/home\/httpd\/html\/*" "\/var\/lib\/pgsql\/data\/*" "\/usr\/local\/mysql\/data\/*" "\/var\/lib\/mysql\/*" "\/var\/vsftpd\/*" "\/etc\/bind\/*" "\/var\/named\/*" "*\/public_html\/*") AND type:"SYSCALL")"""
    doc = {
        'sigma_doc_id': 'BOMU1GIBKGOT5RVDSBYy',
        'backend': 'es-qs',
        'hash': hashlib.sha256(text).hexdigest(),
        'text': text
        }
    doc_list.append(doc)



    text = '''((("tmp")) OR (("www") AND ("var")) OR (("usr") AND ("local") AND ("apache2")) OR (("httpd") AND ("usr") AND ("local")) OR (("apache") AND ("var")) OR (("srv") AND ("www")) OR (("httpd") AND ("html") AND ("home")) OR (("lib") AND ("data") AND ("pgsql") AND ("var")) OR (("data") AND ("usr") AND ("local") AND ("mysql")) OR (("lib") AND ("mysql") AND ("var")) OR (("vsftpd") AND ("var")) OR (("bind") AND ("etc")) OR (("named") AND ("var")) OR (("html") AND ("public")) AND ("SYSCALL")) AND type != 2 | rex field = flexString1 mode=sed "s//Sigma: Program Executions in Suspicious Folders/g"'''
    doc = {
        'sigma_doc_id': 'BOMU1GIBKGOT5RVDSBYy',
        'backend': 'as',
        'hash': hashlib.sha256(text).hexdigest(),
        'text': text
        }
    doc_list.append(doc)



    text = """[
      {
        "_id": "Program-Executions-in-Suspicious-Folders",
        "_type": "search",
        "_source": {
          "title": "Program Executions in Suspicious Folders",
          "description": "Detects program executions in suspicious non-program folders related to malware or hacking activity",
          "hits": 0,
          "columns": [],
          "sort": [
            "@timestamp",
            "desc"
          ],
          "version": 1,
          "kibanaSavedObjectMeta": {
            "searchSourceJSON": "{\"index\": \"*\", \"filter\": [], \"highlight\": {\"pre_tags\": [\"@kibana-highlighted-field@\"], \"post_tags\": [\"@/kibana-highlighted-field@\"], \"fields\": {\"*\": {}}, \"require_field_match\": false, \"fragment_size\": 2147483647}, \"query\": {\"query_string\": {\"query\": \"(exe:(\\\"\\\\/tmp\\\\/*\\\" \\\"\\\\/var\\\\/www\\\\/*\\\" \\\"\\\\/usr\\\\/local\\\\/apache2\\\\/*\\\" \\\"\\\\/usr\\\\/local\\\\/httpd\\\\/*\\\" \\\"\\\\/var\\\\/apache\\\\/*\\\" \\\"\\\\/srv\\\\/www\\\\/*\\\" \\\"\\\\/home\\\\/httpd\\\\/html\\\\/*\\\" \\\"\\\\/var\\\\/lib\\\\/pgsql\\\\/data\\\\/*\\\" \\\"\\\\/usr\\\\/local\\\\/mysql\\\\/data\\\\/*\\\" \\\"\\\\/var\\\\/lib\\\\/mysql\\\\/*\\\" \\\"\\\\/var\\\\/vsftpd\\\\/*\\\" \\\"\\\\/etc\\\\/bind\\\\/*\\\" \\\"\\\\/var\\\\/named\\\\/*\\\" \\\"*\\\\/public_html\\\\/*\\\") AND type:\\\"SYSCALL\\\")\", \"analyze_wildcard\": true}}}"
          }
        }
      }
    ]"""
    doc = {
        'sigma_doc_id': 'BOMU1GIBKGOT5RVDSBYy',
        'backend': 'kibana',
        'hash': hashlib.sha256(text).hexdigest(),
        'text': text
        }
    doc_list.append(doc)



    for doc in doc_list:
        res = es.index(index="sigma_translation", doc_type='sigma_translation', body=doc)
        print(res)

insert_translations()

# #1. Список сигм (все поля)
# # - с фильтрацией по title, description, category, author (условие like) (для фильтра - условие "или", между фильтрами - условие "и")
# # - с фильтрацией по permission_id (условие in)
# # - с фильтрацией по user_id (условие in)
# # - сортировка по любому из полей
# # - возможность указать limit, offset
# # - возможность отсортировать по релевантности
# #
# #2. Получение сигмы по id  (все поля)
# #
# #3. Список сигм по title  (все поля)
# # - с фильтрацией по title (условие like)
# # - с фильтрацией по user_id (условие in)
# # - с фильтрацией по permission_id (условие in)
# #
# #4. Получение списка уникальных категорий сигмы (только поле category) (для фильтра)
# # - с фильтрацией по category (условие like)
# # - с фильтрацией по user_id (условие in)
# # - с фильтрацией по permission_id (условие in)


def filter1():
    query = {
        "size": 10000,
        "query": {
            "bool": {
                "must": [
                     {"bool":
                       {"should": [
                              { "match": { "sigma_text": "test" }},   # OR
                              { "match": { "sigma_text": "Program Executions"}}
                            ]}
                     },
                    #{"terms" : { "user_id" : [1, 2]}},
                    {"terms" : { "permission_id" : [1, 2, 3]}},
                    ]
            },
        },
        "sort" : [
            #{ "title" : "asc"},
            #{ "author" : "asc"},
            #{ "released" : "asc"},
            "_score"
        ],
    }

    res = es.search(index="sigma_doc", body=query)
    for hit in res['hits']['hits']:
        print hit['_id']



def filter2():
##    res = es.get(index="sigma_doc", doc_type='sigma_doc', id='KuPSvmIBKGOT5RVDpRLT')
##    print(res)
    query = {
        "query": {
            "ids" : {
                "type" : "sigma_doc",
                "values" : ["KuPSvmIBKGOT5RVDpRLT"]
            }
        }
    }
    res = es.search(index="sigma_doc", body=query)
    print res


def filter3():
    query = {
        "size": 10000,
        "query": {
            "bool": {
                "must": [
                    {"match" : {"title": "Program" }}, # like по title
                    {"terms" : { "user_id" : [1, 2]}},
                    {"terms" : { "permission_id" : [1, 2, 3]}},
                    ]
            },
        }
    }

    res = es.search(index="sigma_doc", body=query)
    for hit in res['hits']['hits']:
        print hit['_id']


def filter4():
    query = {
        "size": 0,
        "query": {
            "bool": {
                "must": [
                    #{"terms" : {"category": [1,2,9] }},
                    {"terms" : { "user_id" : [1, 2]}},
                    {"terms" : { "permission_id" : [1, 2, 3]}},
                    ]
            },
        },
        "aggs" : {
            "categories" : {
                "terms" : { "field" : "category",  "size" : 10000 }
            }
        }
    }


    res = es.search(index="sigma_doc", body=query)
    for hit in res['aggregations']['categories']['buckets']:
        print hit['key']


text = """title: Program Executions in Suspicious Folders
status: experimental
description: Detects program executions in suspicious non-program folders related to malware or hacking activity
references:
    - 'Internal Research'
date: 2018/01/23
author: Florian Roth
logsource:
    product: linux
    service: auditd
detection:
    selection:
        type: 'SYSCALL'
        exe:
            # Temporary folder
            - '/tmp/*'
            # Web server
            - '/var/www/*'            # Standard
            - '/usr/local/apache2/*'  # Classical Apache
            - '/usr/local/httpd/*'    # Old SuSE Linux 6.*
            - '/var/apache/*'         # Solaris
            - '/srv/www/*'            # SuSE Linux 9.*
            - '/home/httpd/html/*'    # Redhat 6 or older
            # Data dirs of typically exploited services (incomplete list)
            - '/var/lib/pgsql/data/*'
            - '/usr/local/mysql/data/*'
            - '/var/lib/mysql/*'
            - '/var/vsftpd/*'
            - '/etc/bind/*'
            - '/var/named/*'
            # Others
            - '*/public_html/*'
    condition: selection
falsepositives:
    - Admin activity (especially in /tmp folders)
    - Crazy web applications
level: medium"""

#print hashlib.sha256(text).hexdigest()