﻿#!/usr/bin/python

import os
import re
import csv
import datetime
#from filecmp import dircmp
import json
import hashlib
#import base64
import subprocess
#from urllib import urlopen
import requests
import yaml

from logger import Logger
from pm_db_connector import PM_DB_Connector
from es_db_connector import ES_DB_Connector
from es_config import devp

all_backends = ["kibana", "xpack-watcher", "logpoint", "splunk", "grep", "as", "qualys", "graylog", "qradar"]
url_sigma_repo = 'https://github.com/Neo23x0/sigma'
currentdir = os.path.dirname(os.path.abspath(__file__))
path = '/srv/sigma_git/' # for prod
if not os.path.exists(path):
    path = os.path.normpath(currentdir + '/sigma_git/') # for local testing


sigma_config_path = os.path.normpath(currentdir + '/tools/config/')
converter_path = os.path.normpath(currentdir + '/tools/sigmac.py')

class GIT_Connector(object):
    def __init__(self):
        self.url_sigma_repo = 'https://api.github.com/repos/Neo23x0/sigma'      
        self.headers = {'Content-Type': 'application/json',
                        'Accept': 'application/json'
                        }        
        
    def get(self, path):
        try:           
            r = requests.get(self.url_sigma_repo + path, headers=self.headers, verify=False)           
            return r.json()       
        except Exception as e:
            raise Exception ("GitHub connection Error: {}".format(str(e)))
         
    def get_last_commit(self):
        return self.get('/commits')[0]['sha']             
        
        
    def get_commits_difference(self, old_sha, new_sha):    
        #new_sha = self.get_last_commit()
        return self.get('/compare/{}...Neo23x0:{}'.format(old_sha, new_sha))
     
reptrn_git_filepath = re.compile(r'\/rules((?:\/[^\/]+?)+\.yml)')        
def get_sigma_category(filepath):
    git_filepath = None
    category_id = None
    match = reptrn_git_filepath.search(filepath)
    if match:
        git_filepath = match.group(1)
        category_path = os.path.split(git_filepath)[0]
        category_id = category_tree_dict.get(category_path)
    
    return (git_filepath, category_id)


def parse_file(filepath):
    (git_filepath, category) = get_sigma_category(filepath)
    # print(git_filepath, category)
    with open(filepath, 'r') as stream:
        text = "".join(line for line in stream if not line.isspace()) #stream.read()
        data = yaml.load(text)

        author = data.get('author')
        if type(author) == list:
            author = ", ".join(author)

        return {
            'permission_id': 3,
            'title': data['title'],
            'description': data.get('description', '').replace('\'', '\\\''),
            'status': data.get('status', ''),
            'level': data.get('level'),
            'category': category,
            'author': author,
            'released': (datetime.datetime.now().replace(microsecond=0)),
            'sigma_text': text,
            'git_filepath': git_filepath,
            }


def exec_shell_command(command):
    p = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    p.wait()
    return (p.returncode, p.stdout.read().strip(), p.stderr.read().strip())

def translate_sigma(filepath, out_format):
    exit_code = 0
    rezult = ''

    # маппинг бекенда и конфига
    if out_format == 'as':
        sigma_config = '-c ' + os.path.normpath(sigma_config_path + '/arcsight.yml')
    elif out_format == 'qualys':
        sigma_config = '-c ' + os.path.normpath(sigma_config_path + '/qualys.yml')
    elif out_format == 'qradar':
        sigma_config = '-c ' + os.path.normpath(sigma_config_path + '/qradar.yml')
    else:
        sigma_config = ''

    command = "/usr/local/bin/python3.6 {} {} -t {} {}".format(converter_path, sigma_config, out_format, filepath) #/usr/local/bin/python3.6
    # command = "/usr/bin/python3 {} {} -t {} {}".format(converter_path, sigma_config, out_format, filepath)  # /usr/local/bin/python3.6
    #logger.info("Command {}".format(command))
    (exit_code, rezult, error_text) = exec_shell_command(command)

    if exit_code == 0:
        return rezult
    else:
        raise Exception(error_text)


def update_sigma_translations(filepath, sigma_doc_id):
    for backend_name in all_backends:
        try:
            text = translate_sigma(filepath, backend_name)
            if text:
                data = {
                    'sigma_doc_id': sigma_doc_id,
                    'backend': backend_name,
                    'text': text
                    }
                es_dbc.upsert_sigma_translations(data)
        except Exception as e:
            logger.error("Sigma translation error [{}, {}]: {}".format(sigma_doc_id, backend_name, str(e)))

def get_last_commit_id():
    try:
        with open(os.path.normpath(currentdir + '/last_commit_sha.ini'), 'r') as f: 
            csvreader = csv.reader(f, delimiter=',')
            row = csvreader.next()
            return row[0]
    except Exception as e:
        logger.warning("last_commit_sha.ini not found, it is first run")
        return None

def set_last_commit_id(sha):
    with open(os.path.normpath(currentdir + '/last_commit_sha.ini'), 'w') as f:
        f.write("{},{}".format(str(sha), datetime.datetime.now().isoformat()))        

def empty_folder(path, url):
    global does_not_parse
    
    logger.info("Folder is empty")
    
    os.chdir(path)
    os.system('git clone {}'.format(url))
    os.chdir(os.path.normpath(path + '/sigma/'))
    os.system('git remote add upstream {}.git'.format(url))
    
    git_path = os.path.normpath(path + '/sigma/rules/')
    for root, dirs, files in os.walk(git_path, topdown=False):
        for sigma in files:
            add_sigma = os.path.join(root, sigma)
            try:
                add_sigma_to_db = parse_file(add_sigma)
                # print("add_sigma_to_db", add_sigma_to_db)
                logger.info("Parse file {}".format(add_sigma))
                sigma_doc_id = es_dbc.insert_sigma_doc(add_sigma_to_db)
                logger.info("New document inserted {} with id {}".format(add_sigma, sigma_doc_id))
                update_sigma_translations(add_sigma, sigma_doc_id)

            except Exception as e:
                logger.warning("Document parsing error: {} in {}".format(str(e), add_sigma))
                does_not_parse.append(add_sigma)
    
    sha = git_con.get_last_commit()
    set_last_commit_id(sha)
    logger.info("{} sha was saved to 'last_commit_sha' file".format(sha))


def check_sigma_changes():
    global does_not_parse

    updated_ids = []
    added_ids = []
    
    sha = get_last_commit_id()
    new_sha = git_con.get_last_commit()
    print(sha, new_sha)
    if new_sha == sha:
        logger.info("{} is actual commit".format(sha))
        return
    else:
        logger.info("Get diff from {} to {}".format(sha, new_sha))
    ##############################################

    os.chdir(os.path.normpath(path + '/sigma/'))
    os.system('git reset --hard HEAD')
    os.system('git pull')
    
    files_list = git_con.get_commits_difference(sha, new_sha).get('files', [])
    files_list = [x for x in files_list if x['filename'].startswith('rules/')]
    print(len(files_list))
    added_file_list = []
    modified_file_list = []
    for file in files_list:
    	if file['status'] == 'added':
    		added_file_list.append(file)
    	elif file['status'] == 'modified':
    		modified_file_list.append(file)
    	else:
    		pass
    print('added', len(added_file_list), 'modified', len(modified_file_list))

    for git_file in files_list:
        status = git_file['status']
        # print(status)
        file_name = git_file['filename'].encode('utf8')
        file_name = os.path.normpath(path + '/sigma/' + file_name)
        # print(file_name)
        if status in ['added', 'modified']:
            try:
                logger.info("Parse file {}".format(file_name))
                sigma_doc = parse_file(file_name)
                # print('sigma_doc', sigma_doc)
                #logger.info("Parsed {}".format(sigma_doc))
                if status == 'added':             
                    sigma_doc_id = es_dbc.insert_sigma_doc(sigma_doc)
                    # print(sigma_doc_id)
                    added_ids.append(sigma_doc_id)
                    
                    logger.info("New document inserted {} with id {}".format(file_name, sigma_doc_id))
                else:
                    sigma_doc_id = es_dbc.update_sigma_doc(sigma_doc)
                    updated_ids.append(sigma_doc_id)
                    logger.info("Document updated {}, id {}".format(file_name, sigma_doc_id))
                
                update_sigma_translations(file_name, sigma_doc_id)
            except Exception as e:
                logger.error("{}: {}".format(file_name, str(e)))
                logger.logger.exception(str(e))
                does_not_parse.append(file_name)
                
        elif status == 'renamed':
            logger.info("renamed!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
            try:
                old_git_filepath = git_file['previous_filename']
                sigma_doc_id = es_dbc.sigma_doc_git_dict.get(old_git_filepath)           
                if not sigma_doc_id:
                    # insert new
                    logger.info("Parse file {}".format(file_name))
                    #logger.info("Parsed {}".format(sigma_doc))
                    sigma_doc = parse_file(file_name)   
                    sigma_doc_id = es_dbc.insert_sigma_doc(sigma_doc)
                    added_ids.append(sigma_doc_id)
                    logger.info("New document inserted {} with id {}".format(file_name, sigma_doc_id))   
                    update_sigma_translations(file_name, sigma_doc_id)                          
                else:
                    # update git_filepath
                    (git_filepath, category) = get_sigma_category(file_name)
                    rename_doc = {
                        'sigma_doc_id': sigma_doc_id,
                        'category': category,
                        'git_filepath': git_filepath,
                        }                
                    es_dbc.rename_sigma_doc(rename_doc)
                    updated_ids.append(sigma_doc_id)
                    logger.info("Document id {} renamed from {} to {}".format(sigma_doc_id, old_git_filepath, file_name)) 
            except Exception as e:
                logger.error("{}: {}".format(file_name, str(e)))
                logger.logger.exception(str(e))
                does_not_parse.append(file_name)                    
        else:
            logger.warning("File has status {}, {}".format(status, file_name))    
     
    set_last_commit_id(new_sha) 
    
    return (added_ids, updated_ids)

def report_changes(added_ids, updated_ids):
    if updated_ids or added_ids:
        # for admins
        # pass
        send_updated_added_ids = devp
        # send_updated_added_ids = '/opt/php70/bin/php /www/test-uclsocadmin/data/www/con.ucl.socprime.name/public/index.php added-or-updated-sigma --created-id={} --updated-id={}  > /dev/null'
        send_updated = "'" + send_updated_added_ids.format(",".join(updated_ids), ",".join(added_ids)) + "'"
        # print('send_updated', send_updated)
        os.system(send_updated)
        
        # for users
        dbc.insert_notifications(added_ids, updated_ids)
        
    if added_ids:    
        logger.info('Inserted {}'.format(added_ids))
    if updated_ids:    
        logger.info('Updated {}'.format(updated_ids))        
        

if __name__ == '__main__':
    logger = Logger("sigmaUpdate")
    logger.info('= Started ==================')   
    does_not_parse = list()
##    updated_ids = list()
##    added_ids = list()
    category_tree_dict = {}

    dbc = PM_DB_Connector()
    es_dbc = ES_DB_Connector()
    git_con = GIT_Connector()

    category_tree_dict = dbc.get_category_tree_dict()
    if not get_last_commit_id():
        empty_folder(path, url_sigma_repo) 
    else:
        res = check_sigma_changes()
        # print(res)
        if res == None:
        	pass
        else:
	        added_ids = res[0]
	        print(len(added_ids), added_ids)
	        updated_ids = res[1]
	        print(len(updated_ids), updated_ids)
	        report_changes(added_ids, updated_ids)

    if does_not_parse:
        logger.warning("Files were not parsed: {}".format(does_not_parse))     

