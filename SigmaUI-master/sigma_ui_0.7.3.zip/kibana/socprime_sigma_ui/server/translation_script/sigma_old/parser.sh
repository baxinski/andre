#!/bin/bash

SHELL=/bin/bash
USER=root
MAIL=/var/spool/mail/root
PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin:/root/bin
PWD=/root
HOME=/root
LOGNAME=root

/usr/bin/python2.7 /srv/scripts/sigma/sigma_converter.py "$1" "$2" "$3"


