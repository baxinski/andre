﻿from datetime import datetime
import hashlib
from elasticsearch import Elasticsearch

from es_config import *

UTC_OFFSET_TIMEDELTA = datetime.utcnow() - datetime.now()

class ES_DB_Connector(object):

    def __init__(self):
        self.es = Elasticsearch(
            ES_host,
            http_auth=ES_http_auth,
            scheme=ES_scheme,
            port=ES_port,
        )
        self.sigma_doc_git_dict = {}
        self.get_sigma_doc_git_dict()

    def insert_sigma_doc(self, data):
        doc = {
            'user_id': None,
            'permission_id': 3, #!!!!!!!!!!!!!!!!!!!
            'title': data['title'],
            'title_keyword': data['title'],
            'status': data['status'],
            'level': data['level'],
            'author': data['author'],
            'author_keyword': data['author'],
            'sigma_text': data['sigma_text'],

            'hash': hashlib.sha256(data['sigma_text']).hexdigest(),
            'git_filepath': data['git_filepath'],
            'category': data['category'],

            'released': datetime.utcnow(),
            'updated': datetime.utcnow(),
            'downloads': 0,
            'mitre_attack': None,
            'is_verified': False
        }

        res = self.es.index(index=SIGMA_DOC_INDEX_NAME, doc_type=SIGMA_DOC_INDEX_NAME, body=doc)
        return res['_id']

    def update_sigma_doc(self, data):
        # поиск по git_filepath -> id
        doc_id = self.sigma_doc_git_dict.get(data['git_filepath'])
        if doc_id:
            #update по id
            doc = {
                'title': data['title'],
                'title_keyword': data['title'],
                'status': data['status'],
                'level': data['level'],
                'author': data['author'],
                'author_keyword': data['author'],
                'sigma_text': data['sigma_text'],

                'hash': hashlib.sha256(data['sigma_text']).hexdigest(),
                'category': data['category'],

                'updated': datetime.utcnow(),
                'is_verified': False
            }
            self.es.update(
                index=SIGMA_DOC_INDEX_NAME,
                doc_type=SIGMA_DOC_INDEX_NAME,
                id=doc_id,
                body={"doc": doc}
                )
            return doc_id
        else:
            raise Exception('Not found sigma_doc with git_filepath: {}'.format(data['git_filepath']))


    def rename_sigma_doc(self, data):
        doc = {
            'category': data['category'],
            'git_filepath': data['git_filepath'],
        }
        self.es.update(
            index=SIGMA_DOC_INDEX_NAME,
            doc_type=SIGMA_DOC_INDEX_NAME,
            id=data['sigma_doc_id'],
            body={"doc": doc}
            ) 


    def get_sigma_doc_git_dict(self):
        query = {
            "size": 10000,
            "_source": ["git_filepath"],
            "query" : {
                "exists": {
                    "field": "git_filepath"
                }
            }}
        try:
            res = self.es.search(index=SIGMA_DOC_INDEX_NAME, body=query)
            self.sigma_doc_git_dict = {}
            for hit in res['hits']['hits']:
                self.sigma_doc_git_dict[hit['_source']['git_filepath']] = hit['_id']
        except:
            pass
        
    def get_all_sigma_doc_list(self):
        query = {
            "size": 10000,
            "_source": ["_id"],
            "query" : { 
                "term" : { "permission_id" : 3}
                }
            }
        try:
            res = self.es.search(index=SIGMA_DOC_INDEX_NAME, body=query)
            sigma_doc_list = []
            for hit in res['hits']['hits']:
                sigma_doc_list.append(hit['_id'])
            
            return sigma_doc_list
        except:
            pass        
        
    def get_sigma_doc_by_id(self, sigma_doc_id):
        try:
            res = self.es.get(index=SIGMA_DOC_INDEX_NAME, doc_type=SIGMA_DOC_INDEX_NAME, id=sigma_doc_id)
            return res["_source"]
        except:
            raise Exception('Not found sigma_doc with id: {}'.format(sigma_doc_id))               
        

    def upsert_sigma_translations(self, data):
        doc_id = '{}_{}'.format(data['sigma_doc_id'], data['backend'])
        text_hash = hashlib.sha256(data['text']).hexdigest()

        doc_insert = {
            'sigma_doc_id': data['sigma_doc_id'],
            'backend': data['backend'],
            'hash': text_hash,
            'text': data['text']
            }

        doc_update = {
            'hash': text_hash,
            'text': data['text']
            }

        self.es.update(
            index=SIGMA_TRANSLATION_INDEX_NAME,
            doc_type=SIGMA_TRANSLATION_INDEX_NAME,
            id=doc_id,
            body={"doc": doc_update, "upsert": doc_insert}
            )

    def mark_as_verified(self, git_filepath):
        # поиск по git_filepath -> id
        doc_id = self.sigma_doc_git_dict.get(git_filepath)
        if doc_id:
            #update по id
            self.mark_as_verified_by_id(doc_id)
            print 'OK', git_filepath
        else:
            print ('Not found sigma_doc with git_filepath: {}'.format(git_filepath))        


    def mark_as_verified_by_id(self, doc_id):
        doc = {
            'is_verified': True
        }
        self.es.update(
            index=SIGMA_DOC_INDEX_NAME,
            doc_type=SIGMA_DOC_INDEX_NAME,
            id=doc_id,
            body={"doc": doc}
            )
        print 'OK', doc_id


    def update_views_count(self, doc_id, count):       
        body = {
            "script" : {
                "source": "ctx._source.views = params.count",
                "lang": "painless",
                "params" : {
                    "count" : count
                }
            }
        }  
        
        self.es.update(
            index=SIGMA_DOC_INDEX_NAME,
            doc_type=SIGMA_DOC_INDEX_NAME,
            id=doc_id,
            body=body
            )        
if __name__ == "__main__":
    es = ES_DB_Connector()
##    es.get_sigma_doc_git_dict()
##    print es.sigma_doc_git_dict

#    with open('verified_list.txt', 'r') as f: 
        # for git_filepath in f:
            # es.mark_as_verified(git_filepath.strip())
            
    with open('sigma_doc_views_test.csv', 'r') as f: 
        for row in f:
            try:
                l = row.strip().split(',')     
                print l[0], l[1]
                es.update_views_count(l[0], l[1])
            except Exception as e:
                print e        
        